
# Detailed transcription record

## Segments

| Segment | Occurrence | BIPA | CLTS SoundClass |
|-----------|--------------|--------|-------------------|

(0 rows)



## Unsegmentable lexemes (up to 100 only)

| ID | LANGUAGE | CONCEPT | FORM |
|------|------------|-----------|--------|

(0 rows)



## Words with invalid segments (up to 100 only)

| ID | LANGUAGE | CONCEPT | FORM | SEGMENTS |
|------|------------|-----------|--------|------------|

(0 rows)


